#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <color.h>
#define SPEED 500000
int main(){
reset();
printf("\n");

  int i=0;
  for(i=0;i<100;i++){
    if(i%3==0){
        red();
	printf("\n");
    }else if(i%3==1){
	yellow();
	printf("\n");
    }else{
	reset();
	printf("\n");
    }	
    system("clear");
    usleep(SPEED);
    system("figlet P");
    usleep(SPEED);
    system("clear");
    system("figlet PH");
    usleep(SPEED);
    system("clear");
    system("figlet PHA");
    usleep(SPEED);
    system("clear");
    system("figlet PHAR");
    usleep(SPEED);
    system("clear");
    system("figlet PHARM");
    usleep(SPEED);
    system("clear");
    system("figlet PHARMA");
    usleep(SPEED);
    system("clear");
    system("figlet PHARMAC");
    usleep(SPEED);
    system("clear");
   system("figlet PHARMACI");
    usleep(SPEED);
    system("clear");
    system("figlet PHARMACIE");
    usleep(SPEED);
    system("clear");



  }
reset();

}
