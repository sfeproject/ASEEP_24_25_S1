package com.param;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edM;
    private Spinner spD;
    private SeekBar seekNb;
    private RadioGroup rdgP;
    private CheckBox chA;
    private Button btnE;
    private Button btnA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        edM=findViewById(R.id.edM);
        spD=findViewById(R.id.spD);
        seekNb=findViewById(R.id.seekNb);
        rdgP=findViewById(R.id.rdgP);
        chA=findViewById(R.id.chA);
        btnE=findViewById(R.id.btnE);
        btnA=findViewById(R.id.btnA);
       
    }

    

}