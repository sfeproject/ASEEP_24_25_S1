package radio.com.myapplication;

public class Tache {
    private int id;
    private String nom;
    private int avn;

    public Tache(int id, String nom, int avn) {
        this.id = id;
        this.nom = nom;
        this.avn = avn;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public int getAvn() {
        return avn;
    }

    @Override
    public String toString() {
        return  id + " - "+ nom+" - "+ avn+"%" ;
    }
}
