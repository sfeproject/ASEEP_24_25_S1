package radio.com.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
   
    private Button btnAjouter;
    private Button btnQuitter;
    private ListView lstT;
    private ArrayAdapter<Tache> adpT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnAjouter=findViewById(R.id.btnAjout);
        btnQuitter=findViewById(R.id.btnQuitter);
        lstT=findViewById(R.id.lstTache);
        adpT=new ArrayAdapter<Tache>(this,android.R.layout.simple_list_item_1);
        lstT.setAdapter(adpT);
        ajouterEcouteurs();
       
    }

   
   


}
