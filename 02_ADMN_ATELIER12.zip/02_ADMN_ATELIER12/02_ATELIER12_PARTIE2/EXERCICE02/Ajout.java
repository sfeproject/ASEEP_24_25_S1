package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Ajout extends AppCompatActivity {
    private EditText edNom;
    private Button btnAjouter;
    private Button btnAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
        init();
    }

    private void init() {
        edNom=findViewById(R.id.edNom);
        btnAjouter=findViewById(R.id.btnAjouter);
        btnAnnuler=findViewById(R.id.btnAnnuler);
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajouter();
            }
        });
        btnAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                annuler();
            }
        });

    }

    private void ajouter() {
       
    }
    private void annuler() {
        
    }
}
