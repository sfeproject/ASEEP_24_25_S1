#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <color.h>
#define SPEED 500000
int main(){
red();
printf("abc\n");

//  int i=0;
//  for(i=0;i<100;i++){
//    system("clear");
//    usleep(SPEED);
//    system("figlet PH");
//    usleep(SPEED);
//    system("figlet AR");
//    usleep(SPEED);
//    system("figlet MA");
//    usleep(SPEED);
//    system("figlet CIE");
//    usleep(SPEED);
// 
//
//
//
//
//
//  }
reset();

}
