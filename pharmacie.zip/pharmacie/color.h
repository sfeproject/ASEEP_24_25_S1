
void red ();

void yellow ();

void reset () ;

